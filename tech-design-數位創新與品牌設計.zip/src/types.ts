export interface NavItem {
  id: string;
  label: string;
  href: string;
  children?: { id: string; label: string; href: string; description?: string }[];
}

export interface CarouselSlide {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  ctaText: string;
  ctaLink: string;
  badge: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  category: string;
  shortDesc: string;
  fullDesc: string;
  image: string;
  iconName: string;
  features: string[];
  deliverables: string[];
  tags: string[];
  badge?: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  client: string;
  category: 'web' | 'uiux' | 'brand' | 'system';
  categoryLabel: string;
  image: string;
  description: string;
  impactMetric: string;
  impactLabel: string;
  tags: string[];
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  role: string;
  company: string;
  avatar: string;
  rating: number;
}

export interface TransitInfo {
  type: 'mrt' | 'bus' | 'car' | 'ubike';
  title: string;
  description: string;
  details: string[];
  icon: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  company: string;
  service: string;
  budget: string;
  message: string;
}
