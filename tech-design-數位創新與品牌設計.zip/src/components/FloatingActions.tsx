import React, { useState, useEffect } from 'react';
import { Phone, MapPin, ArrowUp, Send, MessageSquare } from 'lucide-react';
import { COMPANY_INFO } from '../data/mockData';

export const FloatingActions: React.FC = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Mobile-only Bottom Quick Action Bar */}
      <div
        id="mobile-quick-action-bar"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0c0c0c]/95 backdrop-blur-xl border-t border-white/10 px-3 py-2 flex items-center justify-around gap-2 shadow-2xl"
      >
        <a
          href={`tel:${COMPANY_INFO.phone}`}
          className="flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl text-neutral-300 hover:text-[#c5a059] active:bg-white/5 transition-colors"
          aria-label="撥打電話"
        >
          <Phone className="w-4 h-4 text-[#c5a059]" />
          <span className="text-[10px] font-medium mt-0.5">一鍵通話</span>
        </a>

        <a
          href={COMPANY_INFO.googleMapsDirectionsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex flex-col items-center justify-center py-1.5 px-2 rounded-xl text-neutral-300 hover:text-[#c5a059] active:bg-white/5 transition-colors"
          aria-label="Google地圖導航"
        >
          <MapPin className="w-4 h-4 text-[#c5a059]" />
          <span className="text-[10px] font-medium mt-0.5">大安分部導航</span>
        </a>

        <a
          href="#contact"
          className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-[#c5a059] to-[#d8b56f] text-black font-bold text-xs shadow-md shadow-[#c5a059]/25 active:scale-95 transition-all"
        >
          <Send className="w-3.5 h-3.5" />
          <span>預約諮詢</span>
        </a>
      </div>

      {/* Floating Back to Top Button (Desktop / Tablet) */}
      {showScrollTop && (
        <button
          type="button"
          onClick={scrollToTop}
          id="floating-back-to-top-btn"
          className="hidden sm:flex fixed bottom-6 right-6 z-40 p-3 rounded-full bg-[#161616] text-[#c5a059] hover:bg-[#c5a059] hover:text-black shadow-2xl border border-white/15 transition-all active:scale-90 items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#c5a059] cursor-pointer"
          aria-label="快速回到頂部"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
    </>
  );
};
