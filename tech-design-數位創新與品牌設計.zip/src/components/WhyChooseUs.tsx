import React from 'react';
import {
  Sparkles,
  Zap,
  ShieldCheck,
  LineChart,
  Building2,
  Star,
  CheckCircle2,
  Quote,
} from 'lucide-react';
import { TESTIMONIALS, COMPANY_INFO } from '../data/mockData';

export const WhyChooseUs: React.FC = () => {
  const pillars = [
    {
      icon: <Zap className="w-6 h-6 text-[#c5a059]" />,
      title: '極致載入速度與效能',
      desc: '嚴格遵從 Google Core Web Vitals 標準，透過代碼分割、SSR 與 CDN 邊緣加速，實現 0.8 秒內的首屏渲染。',
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-[#c5a059]" />,
      title: '企業級資安與合規',
      desc: 'SSL 憑證加密、自動快照備份、OWASP 資安防護標準，讓您的商業系統在雲端高枕無憂。',
    },
    {
      icon: <LineChart className="w-6 h-6 text-[#c5a059]" />,
      title: '以轉化為核心的 UX 設計',
      desc: '不只好看，更注重使用者行為路徑分析與按鈕 CTA 佈局，最大化將訪客轉換為實質成交客戶。',
    },
    {
      icon: <Building2 className="w-6 h-6 text-[#c5a059]" />,
      title: '大安分部實體信賴保障',
      desc: `進駐${COMPANY_INFO.schoolLocation}，提供透明化的專案進度管理與隨時可預約的實體專案會議。`,
    },
  ];

  return (
    <section id="why-us" className="py-20 sm:py-24 bg-[#0a0a0a] text-white relative overflow-hidden scroll-mt-12">
      {/* Background subtle ambiance glow elements */}
      <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 rounded-full bg-[#c5a059]/5 blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-96 h-96 rounded-full bg-[#c5a059]/5 blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#c5a059]/15 text-[#c5a059] text-xs font-bold tracking-wider uppercase mb-3 border border-[#c5a059]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>WHY TECH-DESIGN</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            為什麼頂尖企業選擇與我們合作？
          </h2>
          <p className="mt-4 text-neutral-400 text-base sm:text-lg leading-relaxed">
            我們拒絕千篇一律的套版公式，以工程師的嚴謹與藝術家的眼光，打磨每一行代碼與每一個像素。
          </p>
        </div>

        {/* 4 Pillars Bento Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {pillars.map((pillar, idx) => (
            <div
              key={idx}
              className="p-6 rounded-3xl bg-[#121212] border border-white/10 hover:border-[#c5a059]/50 hover:bg-[#161616] transition-all duration-300 group flex flex-col justify-between"
            >
              <div>
                <div className="p-3.5 rounded-2xl bg-[#1a1a1a] border border-white/10 w-fit mb-4 group-hover:scale-105 group-hover:border-[#c5a059]/40 transition-transform">
                  {pillar.icon}
                </div>
                <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#c5a059] transition-colors">
                  {pillar.title}
                </h3>
                <p className="text-sm text-neutral-400 leading-relaxed">
                  {pillar.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="pt-12 border-t border-white/10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <h3 className="text-2xl font-bold text-white">真實客戶評價與回饋</h3>
            <p className="text-sm text-neutral-400 mt-2">來自各產業客戶的肯定，是我們持續精進的最大動力</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {TESTIMONIALS.map((item) => (
              <div
                key={item.id}
                className="p-6 rounded-3xl bg-[#121212] border border-white/10 hover:border-white/20 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-1 text-[#c5a059] mb-4">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#c5a059]" />
                    ))}
                  </div>
                  <Quote className="w-8 h-8 text-neutral-700 mb-2" />
                  <p className="text-sm text-neutral-300 leading-relaxed italic">
                    "{item.quote}"
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 flex items-center gap-3">
                  <img
                    src={item.avatar}
                    alt={item.author}
                    className="w-10 h-10 rounded-full object-cover border border-white/20"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="text-sm font-semibold text-white">{item.author}</div>
                    <div className="text-xs text-neutral-400">{item.role} ・ {item.company}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
