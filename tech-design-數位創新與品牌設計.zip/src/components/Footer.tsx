import React from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  ArrowUp,
  Building2,
  ExternalLink,
  Shield,
} from 'lucide-react';
import { COMPANY_INFO, SERVICES_LIST } from '../data/mockData';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#070707] text-neutral-400 text-sm border-t border-white/10">
      {/* Main Footer Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8">
          
          {/* Col 1: Brand & Location (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#c5a059] to-[#ecd192] flex items-center justify-center text-black font-black text-xl shadow-md">
                TD
              </div>
              <div>
                <span className="text-xl font-bold text-white tracking-tight">
                  TECH-DESIGN
                </span>
                <span className="block text-xs text-[#c5a059] font-medium">
                  數位創新與品牌設計工作室
                </span>
              </div>
            </div>

            <p className="text-neutral-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              專注於全方位高品質網頁設計、UI/UX 介面規劃、企業級全端系統架構與品牌數位轉型顧問。
            </p>

            <div className="pt-2 space-y-2.5 text-xs text-neutral-300">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
                <span>
                  <strong className="text-white">地址：</strong>
                  {COMPANY_INFO.address}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <Building2 className="w-4 h-4 text-[#c5a059] shrink-0" />
                <span>
                  <strong className="text-white">據點：</strong>
                  中國文化大學大安分部 3~6 樓
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#c5a059] shrink-0" />
                <span>
                  <strong className="text-white">電話：</strong>
                  <a href={`tel:${COMPANY_INFO.phone}`} className="hover:text-[#c5a059] transition-colors">
                    {COMPANY_INFO.phone}
                  </a>
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#c5a059] shrink-0" />
                <span>
                  <strong className="text-white">信箱：</strong>
                  <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-[#c5a059] transition-colors">
                    {COMPANY_INFO.email}
                  </a>
                </span>
              </div>
            </div>
          </div>

          {/* Col 2: Services Sitemap (3 cols) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase">
              專業服務項目
            </h4>
            <ul className="space-y-2 text-xs">
              {SERVICES_LIST.map((srv) => (
                <li key={srv.id}>
                  <a
                    href="#services"
                    className="hover:text-[#c5a059] transition-colors flex items-center gap-1.5"
                  >
                    <span className="w-1 h-1 rounded-full bg-neutral-600" />
                    <span>{srv.title}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Quick Navigation & Hours (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="text-white font-bold text-sm tracking-wider uppercase">
              服務時間與專案預約
            </h4>

            <div className="p-4 rounded-2xl bg-[#121212] border border-white/10 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-neutral-200">
                <Clock className="w-4 h-4 text-[#c5a059]" />
                <span className="font-semibold text-white">營業時間</span>
              </div>
              <p className="text-neutral-400 pl-6">
                {COMPANY_INFO.hours}
              </p>
              <p className="text-[11px] text-neutral-500 pl-6">
                可提前預約大安分部實體會議室面對面溝通
              </p>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              <a
                href={COMPANY_INFO.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#161616] hover:bg-[#222] border border-white/10 text-neutral-200 text-xs transition-colors"
              >
                <span>Google 地圖導航</span>
                <ExternalLink className="w-3 h-3 text-neutral-400" />
              </a>

              <a
                href="#contact"
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#c5a059] hover:bg-[#d8b56f] text-black text-xs font-bold transition-all shadow-md shadow-[#c5a059]/20"
              >
                <span>線上需求提報</span>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom copyright and back-to-top */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>
            © {new Date().getFullYear()} TECH-DESIGN 數位創新與品牌設計. All rights reserved.
          </p>

          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1 text-neutral-400">
              <Shield className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>SSL 256-bit 資安加密傳輸</span>
            </span>

            <button
              type="button"
              id="footer-back-to-top-btn"
              onClick={scrollToTop}
              className="flex items-center gap-1.5 text-neutral-300 hover:text-[#c5a059] transition-colors focus:outline-none cursor-pointer"
              aria-label="回到網頁頂部"
            >
              <span>回到頂部</span>
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
