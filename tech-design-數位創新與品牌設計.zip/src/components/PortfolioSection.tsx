import React, { useState } from 'react';
import { Sparkles, ArrowUpRight, CheckCircle2 } from 'lucide-react';
import { PORTFOLIO_CASES } from '../data/mockData';

export const PortfolioSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('all');

  const tabs = [
    { id: 'all', label: '全部精選' },
    { id: 'web', label: '網頁設計' },
    { id: 'uiux', label: 'UI/UX 設計' },
    { id: 'system', label: '全端系統開發' },
    { id: 'brand', label: '品牌識別' },
  ];

  const filteredCases = activeTab === 'all'
    ? PORTFOLIO_CASES
    : PORTFOLIO_CASES.filter((c) => c.category === activeTab);

  return (
    <section id="portfolio" className="py-20 sm:py-24 bg-[#0a0a0a] scroll-mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 sm:mb-16 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#c5a059]/15 text-[#c5a059] border border-[#c5a059]/30 text-xs font-bold tracking-wider uppercase mb-3">
              <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>SELECTED CASE STUDIES</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              精選實績案例與成果
            </h2>
            <p className="mt-3 text-neutral-400 text-base leading-relaxed">
              我們為各領域指標企業與創新品牌打造高回報率的數位產品，每一份成果均有實測數據佐證。
            </p>
          </div>

          {/* Filter tabs (Bento Style) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-[#c5a059] text-black shadow-md shadow-[#c5a059]/20 font-bold'
                    : 'bg-[#141414] text-neutral-300 hover:bg-[#202020] border border-white/10'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Bento Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredCases.map((item) => (
            <div
              key={item.id}
              className="group rounded-3xl border border-white/10 hover:border-[#c5a059]/50 overflow-hidden shadow-2xl transition-all duration-300 bg-[#121212] flex flex-col"
            >
              {/* Image Preview with Hover effect */}
              <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-[#161616]">
                <img
                  src={item.image}
                  alt={item.title}
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/30 to-transparent" />

                {/* Floating Metric Badge */}
                <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between text-white">
                  <div className="p-3 rounded-2xl bg-[#0a0a0a]/90 backdrop-blur-md border border-white/10">
                    <span className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#c5a059] to-[#e5cf92] block leading-none">
                      {item.impactMetric}
                    </span>
                    <span className="text-[11px] text-neutral-300 font-medium mt-1 block">
                      {item.impactLabel}
                    </span>
                  </div>
                  <span className="px-3 py-1 rounded-full text-xs font-semibold bg-[#111111]/80 backdrop-blur-md text-neutral-200 border border-white/20">
                    {item.categoryLabel}
                  </span>
                </div>
              </div>

              {/* Card Meta & Detail */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-bold text-[#c5a059] uppercase tracking-wider mb-1">
                    {item.client}
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-[#c5a059] transition-colors flex items-center justify-between">
                    <span>{item.title}</span>
                    <ArrowUpRight className="w-5 h-5 text-neutral-400 group-hover:text-[#c5a059] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0" />
                  </h3>
                  <p className="mt-2.5 text-sm text-neutral-400 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap items-center gap-1.5">
                  {item.tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-[#1a1a1a] text-neutral-300 text-xs font-medium border border-white/5"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
