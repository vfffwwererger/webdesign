import React, { useState } from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Building2,
  Navigation,
  Copy,
  Check,
  Send,
  TrainFront,
  Bus,
  Car,
  Bike,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { COMPANY_INFO, TRANSIT_GUIDE, SERVICES_LIST } from '../data/mockData';
import { ContactFormData } from '../types';

interface ContactSectionProps {
  selectedServicePreFill?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  selectedServicePreFill,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTransitTab, setActiveTransitTab] = useState<'mrt' | 'bus' | 'car' | 'ubike'>('mrt');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: selectedServicePreFill || '響應式網頁設計 (Web Design)',
    budget: 'NT$ 100,000 - 300,000',
    message: '',
  });

  // Update service if pre-filled prop changes
  React.useEffect(() => {
    if (selectedServicePreFill) {
      setFormData((prev) => ({ ...prev, service: selectedServicePreFill }));
    }
  }, [selectedServicePreFill]);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(COMPANY_INFO.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate reliable async submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 900);
  };

  const transitIcons = {
    mrt: <TrainFront className="w-4 h-4" />,
    bus: <Bus className="w-4 h-4" />,
    car: <Car className="w-4 h-4" />,
    ubike: <Bike className="w-4 h-4" />,
  };

  return (
    <section id="contact" className="py-20 sm:py-24 bg-[#0a0a0a] relative scroll-mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#c5a059]/15 text-[#c5a059] border border-[#c5a059]/30 text-xs font-bold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>CONTACT & LOCATION</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            聯絡我們與實體服務中心
          </h2>
          <p className="mt-4 text-neutral-400 text-base sm:text-lg leading-relaxed">
            我們位於臺北市大安區文化大學大安分部，歡迎預約專案諮詢或填寫需求表單，我們將在 24 小時內與您聯繫。
          </p>
        </div>

        {/* Main 2-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* Left Column: Embedded Map, Address Cards & Transit Info (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Primary Address & Highlight Card */}
            <div className="bg-[#121212] rounded-3xl border border-white/10 p-6 sm:p-7 shadow-2xl">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#c5a059] uppercase tracking-wider">
                    <Building2 className="w-4 h-4" />
                    <span>實體研討與服務據點</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    中國文化大學大安分部
                  </h3>
                  <p className="text-neutral-400 text-sm font-medium mt-1">
                    106 臺北市大安區龍安里和平東路一段155號3~6樓
                  </p>
                </div>

                <button
                  type="button"
                  id="copy-address-btn"
                  onClick={handleCopyAddress}
                  className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#1a1a1a] hover:bg-[#252525] border border-white/10 text-neutral-300 hover:text-white text-xs font-semibold transition-colors focus:ring-2 focus:ring-[#c5a059]"
                  aria-label="複製完整地址"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#c5a059]" />
                      <span className="text-[#c5a059]">已複製地址</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-neutral-400" />
                      <span>複製地址</span>
                    </>
                  )}
                </button>
              </div>

              {/* Floor allocation guide */}
              <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-neutral-300">
                <div className="p-2.5 rounded-xl bg-[#181818] text-center border border-white/5 hover:border-[#c5a059]/30 transition-colors">
                  <span className="font-bold text-[#c5a059] block text-sm">3F</span>
                  <span className="text-neutral-400">多功能研討室</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#181818] text-center border border-white/5 hover:border-[#c5a059]/30 transition-colors">
                  <span className="font-bold text-[#c5a059] block text-sm">4F</span>
                  <span className="text-neutral-400">UI/UX 研發中心</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#181818] text-center border border-white/5 hover:border-[#c5a059]/30 transition-colors">
                  <span className="font-bold text-[#c5a059] block text-sm">5F</span>
                  <span className="text-neutral-400">系統工程會議室</span>
                </div>
                <div className="p-2.5 rounded-xl bg-[#181818] text-center border border-white/5 hover:border-[#c5a059]/30 transition-colors">
                  <span className="font-bold text-[#c5a059] block text-sm">6F</span>
                  <span className="text-neutral-400">客戶接待大廳</span>
                </div>
              </div>

              {/* Action Buttons: Direct Google Navigation & Call */}
              <div className="mt-5 flex flex-wrap items-center gap-3">
                <a
                  href={COMPANY_INFO.googleMapsDirectionsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  id="google-maps-directions-link"
                  className="flex-1 min-w-[160px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#c5a059] hover:bg-[#d8b56f] text-black text-xs sm:text-sm font-bold transition-all shadow-md shadow-[#c5a059]/20"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Google 地圖導航</span>
                </a>

                <a
                  href={`tel:${COMPANY_INFO.phone}`}
                  className="flex-1 min-w-[140px] inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#1a1a1a] hover:bg-[#252525] border border-white/10 text-neutral-200 text-xs sm:text-sm font-semibold transition-colors"
                >
                  <Phone className="w-4 h-4 text-[#c5a059]" />
                  <span>撥打電話諮詢</span>
                </a>
              </div>
            </div>

            {/* Embedded Google Map iframe */}
            <div className="bg-[#121212] rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
              <div className="p-3.5 bg-[#161616] border-b border-white/10 flex items-center justify-between text-xs text-neutral-300 font-medium">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#c5a059]" />
                  <span>實體地圖嵌入定位：中國文化大學大安分部</span>
                </div>
                <span className="text-[11px] text-neutral-400">和平東路一段155號</span>
              </div>
              
              <div className="relative w-full h-72 sm:h-80 bg-[#161616]">
                <iframe
                  id="embedded-google-map"
                  title="中國文化大學大安分部地圖"
                  src={COMPANY_INFO.mapEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen={false}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full filter invert-[90%] hue-rotate-180 contrast-90 brightness-95"
                />
              </div>
            </div>

            {/* Transportation Guide Card with Tabs */}
            <div className="bg-[#121212] rounded-3xl border border-white/10 p-6 shadow-2xl">
              <h4 className="text-base font-bold text-white mb-4 flex items-center gap-2">
                <Navigation className="w-4 h-4 text-[#c5a059]" />
                交通乘車指引
              </h4>

              {/* Transit Tabs */}
              <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-4 overflow-x-auto no-scrollbar">
                {(['mrt', 'bus', 'car', 'ubike'] as const).map((tabKey) => {
                  const guide = TRANSIT_GUIDE.find((g) => g.type === tabKey);
                  return (
                    <button
                      key={tabKey}
                      onClick={() => setActiveTransitTab(tabKey)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap ${
                        activeTransitTab === tabKey
                          ? 'bg-[#c5a059] text-black shadow-md shadow-[#c5a059]/20 font-bold'
                          : 'bg-[#181818] text-neutral-300 hover:bg-[#222] border border-white/5'
                      }`}
                    >
                      {transitIcons[tabKey]}
                      <span>{guide?.title.split('指引')[0].split('資訊')[0]}</span>
                    </button>
                  );
                })}
              </div>

              {/* Transit Details */}
              {(() => {
                const current = TRANSIT_GUIDE.find((g) => g.type === activeTransitTab);
                if (!current) return null;
                return (
                  <div className="space-y-2">
                    <p className="text-xs text-neutral-400 font-semibold mb-2">{current.description}：</p>
                    {current.details.map((detail, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-neutral-300 leading-relaxed bg-[#181818] p-3 rounded-xl border border-white/5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#c5a059] shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>

            {/* Direct Contact Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-2xl bg-[#121212] border border-white/10 flex items-center gap-3.5">
                <div className="p-3 rounded-xl bg-[#1a1a1a] text-[#c5a059] border border-white/5">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-neutral-400 font-medium">服務時間</div>
                  <div className="text-sm font-bold text-white mt-0.5">{COMPANY_INFO.hours}</div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-[#121212] border border-white/10 flex items-center gap-3.5">
                <div className="p-3 rounded-xl bg-[#1a1a1a] text-[#c5a059] border border-white/5">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-neutral-400 font-medium">電子信箱</div>
                  <a href={`mailto:${COMPANY_INFO.email}`} className="text-sm font-bold text-white hover:text-[#c5a059] transition-colors mt-0.5 block">
                    {COMPANY_INFO.email}
                  </a>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Online Consultation & Project Booking Form (5 cols) */}
          <div className="lg:col-span-5">
            <div className="bg-[#121212] rounded-3xl border border-white/10 p-6 sm:p-8 shadow-2xl sticky top-24">
              <div className="mb-6">
                <h3 className="text-xl sm:text-2xl font-bold text-white">
                  預約專案諮詢
                </h3>
                <p className="text-neutral-400 text-xs sm:text-sm mt-1">
                  請填寫您的需求資訊，專業顧問將於 1 個工作天內專人回覆。
                </p>
              </div>

              {isSubmitted ? (
                <div className="p-6 rounded-2xl bg-[#1a1a1a] border border-[#c5a059]/40 text-center space-y-4 animate-in fade-in zoom-in-95 duration-200">
                  <div className="w-12 h-12 rounded-full bg-[#c5a059] text-black flex items-center justify-center mx-auto shadow-lg shadow-[#c5a059]/30">
                    <Check className="w-6 h-6 stroke-[3]" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white">諮詢需求已成功送出！</h4>
                    <p className="text-xs sm:text-sm text-neutral-300 mt-1 leading-relaxed">
                      感謝您的洽詢，我們已收到您的專案需求。顧問團隊將盡速評估並透過電話或 Email 與您聯繫。
                    </p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-[#121212] text-xs text-neutral-300 border border-white/10 text-left space-y-1.5">
                    <div><span className="font-bold text-[#c5a059]">洽詢項目：</span>{formData.service}</div>
                    <div><span className="font-bold text-[#c5a059]">聯絡人：</span>{formData.name} ({formData.phone})</div>
                    <div><span className="font-bold text-[#c5a059]">預估預算：</span>{formData.budget}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsSubmitted(false);
                      setFormData({
                        name: '',
                        email: '',
                        phone: '',
                        company: '',
                        service: '響應式網頁設計 (Web Design)',
                        budget: 'NT$ 100,000 - 300,000',
                        message: '',
                      });
                    }}
                    className="w-full py-2.5 text-xs font-semibold text-black bg-[#c5a059] hover:bg-[#d8b56f] rounded-xl transition-all shadow-md"
                  >
                    填寫下一份需求
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="form-name" className="block text-xs font-bold text-neutral-300 mb-1.5">
                        您的姓名 <span className="text-[#c5a059]">*</span>
                      </label>
                      <input
                        type="text"
                        id="form-name"
                        name="name"
                        required
                        placeholder="王小明"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#181818] text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all"
                      />
                    </div>

                    <div>
                      <label htmlFor="form-phone" className="block text-xs font-bold text-neutral-300 mb-1.5">
                        聯絡電話 <span className="text-[#c5a059]">*</span>
                      </label>
                      <input
                        type="tel"
                        id="form-phone"
                        name="phone"
                        required
                        placeholder="0912-345-678"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#181818] text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  {/* Email & Company */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="form-email" className="block text-xs font-bold text-neutral-300 mb-1.5">
                        公司電子郵件 <span className="text-[#c5a059]">*</span>
                      </label>
                      <input
                        type="email"
                        id="form-email"
                        name="email"
                        required
                        placeholder="service@company.com"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#181818] text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all"
                      />
                    </div>

                    <div>
                      <label htmlFor="form-company" className="block text-xs font-bold text-neutral-300 mb-1.5">
                        公司或組織名稱
                      </label>
                      <input
                        type="text"
                        id="form-company"
                        name="company"
                        placeholder="創新科技股份有限公司"
                        value={formData.company}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-[#181818] text-sm text-white placeholder:text-neutral-600 focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  {/* Service Selection */}
                  <div>
                    <label htmlFor="form-service" className="block text-xs font-bold text-neutral-300 mb-1.5">
                      感興趣的服務項目 <span className="text-[#c5a059]">*</span>
                    </label>
                    <select
                      id="form-service"
                      name="service"
                      value={formData.service}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 text-sm text-white bg-[#181818] focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all"
                    >
                      {SERVICES_LIST.map((s) => (
                        <option key={s.id} value={s.title} className="bg-[#181818] text-white">
                          {s.title}
                        </option>
                      ))}
                      <option value="全方位整合專案 (網頁+UIUX+系統+品牌)" className="bg-[#181818] text-white">全方位整合專案 (網頁+UIUX+系統+品牌)</option>
                      <option value="大安分部實體會議預約" className="bg-[#181818] text-white">大安分部實體會議預約洽談</option>
                    </select>
                  </div>

                  {/* Budget */}
                  <div>
                    <label htmlFor="form-budget" className="block text-xs font-bold text-neutral-300 mb-1.5">
                      專案預估預算範圍
                    </label>
                    <select
                      id="form-budget"
                      name="budget"
                      value={formData.budget}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 text-sm text-white bg-[#181818] focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all"
                    >
                      <option value="NT$ 50,000 - 100,000" className="bg-[#181818] text-white">NT$ 50,000 - 100,000（小型品牌專案）</option>
                      <option value="NT$ 100,000 - 300,000" className="bg-[#181818] text-white">NT$ 100,000 - 300,000（標準企業形象/電商）</option>
                      <option value="NT$ 300,000 - 600,000" className="bg-[#181818] text-white">NT$ 300,000 - 600,000（客製化系統平台）</option>
                      <option value="NT$ 600,000 以上" className="bg-[#181818] text-white">NT$ 600,000 以上（大型企業數位轉型）</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label htmlFor="form-message" className="block text-xs font-bold text-neutral-300 mb-1.5">
                      專案需求簡述或預計上線時間
                    </label>
                    <textarea
                      id="form-message"
                      name="message"
                      rows={3}
                      placeholder="請簡述您的專案期望、參考競品風格、功能需求或欲安排之會議時間..."
                      value={formData.message}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 text-sm text-white bg-[#181818] placeholder:text-neutral-600 focus:outline-none focus:ring-2 focus:ring-[#c5a059] focus:border-transparent transition-all resize-none"
                    />
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    id="submit-contact-form-btn"
                    disabled={isSubmitting}
                    className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#c5a059] to-[#d8b56f] hover:from-[#d8b56f] hover:to-[#ecd192] text-black font-bold text-sm transition-all shadow-lg shadow-[#c5a059]/25 flex items-center justify-center gap-2 active:scale-95 disabled:opacity-70 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>立即送出諮詢需求</span>
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-neutral-500 text-center leading-relaxed">
                    我們重視您的資訊隱私，所有資料僅供專案評估與聯絡使用，絕不外洩。
                  </p>
                </form>
              )}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
