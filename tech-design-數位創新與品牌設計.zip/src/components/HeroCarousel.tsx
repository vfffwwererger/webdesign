import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { CAROUSEL_SLIDES, COMPANY_STATS } from '../data/mockData';

export const HeroCarousel: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === CAROUSEL_SLIDES.length - 1 ? 0 : prev + 1));
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === 0 ? CAROUSEL_SLIDES.length - 1 : prev - 1));
  }, []);

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      nextSlide();
    }, 5500);
    return () => clearInterval(timer);
  }, [isPaused, nextSlide]);

  const currentSlide = CAROUSEL_SLIDES[currentIndex];

  return (
    <section
      id="home"
      className="relative w-full overflow-hidden bg-[#0a0a0a]"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      aria-label="首頁焦點橫幅輪播"
    >
      {/* Carousel Viewport */}
      <div className="relative min-h-[560px] h-[75vh] max-h-[850px] w-full flex items-center">
        {/* Background Images with AnimatePresence */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide.id}
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="absolute inset-0 z-0"
          >
            <img
              src={currentSlide.image}
              alt={currentSlide.title}
              className="w-full h-full object-cover object-center"
              loading={currentIndex === 0 ? 'eager' : 'lazy'}
              decoding="async"
              referrerPolicy="no-referrer"
            />
            {/* Elegant Double Overlay for Maximum Text Legibility */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/85 to-[#0a0a0a]/50" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-[#0a0a0a]/40" />
          </motion.div>
        </AnimatePresence>

        {/* Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-12">
          <div className="max-w-2xl lg:max-w-3xl">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="space-y-4 sm:space-y-6"
              >
                {/* Badge */}
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#c5a059]/15 border border-[#c5a059]/35 text-[#c5a059] text-xs font-bold tracking-wider backdrop-blur-md">
                  <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
                  <span>{currentSlide.badge}</span>
                </div>

                {/* Main Headline */}
                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.15]">
                  {currentSlide.title}
                  <span className="block text-2xl sm:text-3xl lg:text-4xl text-transparent bg-clip-text bg-gradient-to-r from-[#c5a059] via-[#e5cf92] to-[#c5a059] font-bold mt-2">
                    {currentSlide.subtitle}
                  </span>
                </h1>

                {/* Description */}
                <p className="text-neutral-300 text-base sm:text-lg lg:text-xl font-normal leading-relaxed max-w-xl">
                  {currentSlide.description}
                </p>

                {/* CTA Buttons */}
                <div className="flex flex-wrap items-center gap-3.5 pt-2">
                  <a
                    href={currentSlide.ctaLink}
                    id={`hero-cta-btn-${currentSlide.id}`}
                    className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl text-base font-bold text-black bg-gradient-to-r from-[#c5a059] to-[#d8b56f] hover:from-[#d8b56f] hover:to-[#ecd192] transition-all shadow-lg shadow-[#c5a059]/25 hover:shadow-[#c5a059]/40 active:scale-95"
                  >
                    <span>{currentSlide.ctaText}</span>
                    <ArrowRight className="w-4 h-4" />
                  </a>

                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl text-base font-semibold text-neutral-200 bg-[#161616]/80 hover:bg-[#222] hover:text-white border border-white/10 hover:border-[#c5a059]/40 backdrop-blur-md transition-all"
                  >
                    <span>親臨文化大安分部洽談</span>
                  </a>
                </div>

                {/* Trust mini-badges */}
                <div className="flex items-center flex-wrap gap-4 pt-2 text-xs text-neutral-400">
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#c5a059]" />
                    <span>即時響應式設計</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#c5a059]" />
                    <span>Google SEO 規範</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-[#c5a059]" />
                    <span>大安分部實體服務</span>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>

        {/* Carousel Arrow Controls */}
        <button
          type="button"
          onClick={prevSlide}
          id="hero-carousel-prev-btn"
          className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-[#111]/80 hover:bg-[#1a1a1a] text-neutral-300 hover:text-white backdrop-blur-md border border-white/10 hover:border-[#c5a059]/50 transition-all focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
          aria-label="上一張投影片"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button
          type="button"
          onClick={nextSlide}
          id="hero-carousel-next-btn"
          className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-[#111]/80 hover:bg-[#1a1a1a] text-neutral-300 hover:text-white backdrop-blur-md border border-white/10 hover:border-[#c5a059]/50 transition-all focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
          aria-label="下一張投影片"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        {/* Bottom Slide Indicators */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
          {CAROUSEL_SLIDES.map((slide, index) => (
            <button
              key={slide.id}
              onClick={() => setCurrentIndex(index)}
              className={`h-2.5 rounded-full transition-all duration-300 focus:outline-none ${
                currentIndex === index
                  ? 'w-8 bg-[#c5a059] shadow-md shadow-[#c5a059]/50'
                  : 'w-2.5 bg-neutral-700/70 hover:bg-neutral-500'
              }`}
              aria-label={`切換至第 ${index + 1} 張投影片: ${slide.title}`}
            />
          ))}
        </div>
      </div>

      {/* Floating Key Statistics Bar (Bento Grid Style) */}
      <div className="border-t border-white/10 bg-[#0d0d0d]/95 backdrop-blur-md py-6 sm:py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {COMPANY_STATS.map((stat, i) => (
              <div
                key={i}
                className="p-4 sm:p-5 rounded-2xl bg-[#141414] border border-white/10 hover:border-[#c5a059]/40 transition-all group"
              >
                <div className="text-2xl sm:text-3xl lg:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#c5a059] to-[#e5cf92]">
                  {stat.value}
                </div>
                <div className="text-sm font-bold text-neutral-200 mt-1.5 group-hover:text-[#c5a059] transition-colors">
                  {stat.label}
                </div>
                <div className="text-xs text-neutral-400 mt-0.5">
                  {stat.sublabel}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
