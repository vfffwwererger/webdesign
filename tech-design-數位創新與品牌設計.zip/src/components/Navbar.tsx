import React, { useState, useEffect } from 'react';
import {
  Menu,
  X,
  Phone,
  Mail,
  MapPin,
  ChevronDown,
  ArrowRight,
  Sparkles,
  Layout,
  Palette,
  Code,
  TrendingUp,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { COMPANY_INFO, SERVICES_LIST } from '../data/mockData';

interface NavbarProps {
  onSelectServiceModal?: (serviceId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onSelectServiceModal }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesDropdownOpen, setServicesDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const serviceIconMap: Record<string, React.ReactNode> = {
    'web-design': <Layout className="w-4 h-4 text-[#c5a059]" />,
    'ui-ux': <Palette className="w-4 h-4 text-[#c5a059]" />,
    'fullstack': <Code className="w-4 h-4 text-[#c5a059]" />,
    'brand-consulting': <Sparkles className="w-4 h-4 text-[#c5a059]" />,
    'seo-growth': <TrendingUp className="w-4 h-4 text-[#c5a059]" />,
    'cloud-security': <ShieldCheck className="w-4 h-4 text-[#c5a059]" />,
  };

  return (
    <>
      {/* Top Header Bar for Contact & Address Info */}
      <div id="top-announcement-bar" className="hidden lg:block bg-[#0d0d0d] text-neutral-400 text-xs py-2.5 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 text-neutral-300 hover:text-[#c5a059] transition-colors">
              <MapPin className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>{COMPANY_INFO.address}</span>
            </div>
            <div className="flex items-center space-x-2 text-neutral-400">
              <Building2 className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>文化大學大安分部 3~6F 辦公室</span>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <a
              href={`tel:${COMPANY_INFO.phone}`}
              className="flex items-center space-x-1.5 hover:text-[#c5a059] transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#c5a059]" />
              <span className="font-semibold text-neutral-200">{COMPANY_INFO.phone}</span>
            </a>
            <a
              href={`mailto:${COMPANY_INFO.email}`}
              className="flex items-center space-x-1.5 hover:text-[#c5a059] transition-colors"
            >
              <Mail className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>{COMPANY_INFO.email}</span>
            </a>
            <span className="text-neutral-700">|</span>
            <span className="text-neutral-400">{COMPANY_INFO.hours}</span>
          </div>
        </div>
      </div>

      {/* Main Sticky Navigation */}
      <header
        id="main-navbar-header"
        className={`sticky top-0 z-40 w-full transition-all duration-300 ${
          isScrolled
            ? 'bg-[#0a0a0a]/95 backdrop-blur-md shadow-2xl border-b border-white/10 py-3'
            : 'bg-[#0a0a0a] text-white border-b border-white/5 py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#home"
              id="brand-logo-link"
              className="flex items-center gap-3 group focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#c5a059] to-[#8f7034] flex items-center justify-center shadow-lg shadow-[#c5a059]/20 group-hover:scale-105 transition-transform border border-[#c5a059]/40">
                <span className="text-black font-black text-xl tracking-tighter">TD</span>
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold tracking-tight text-white group-hover:text-[#c5a059] transition-colors">
                  TECH-DESIGN
                </span>
                <span className="text-[11px] text-neutral-400 font-medium tracking-wide">
                  數位創新與品牌設計
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
              <a
                href="#home"
                id="nav-home-link"
                className="px-3.5 py-2 text-sm font-medium text-neutral-300 hover:text-[#c5a059] hover:bg-white/5 rounded-xl transition-colors"
              >
                首頁
              </a>

              {/* Services Dropdown */}
              <div
                className="relative"
                onMouseEnter={() => setServicesDropdownOpen(true)}
                onMouseLeave={() => setServicesDropdownOpen(false)}
              >
                <a
                  href="#services"
                  id="nav-services-dropdown-btn"
                  className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-neutral-300 hover:text-[#c5a059] hover:bg-white/5 rounded-xl transition-colors"
                  onClick={() => setServicesDropdownOpen(!servicesDropdownOpen)}
                >
                  <span>服務項目</span>
                  <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${servicesDropdownOpen ? 'rotate-180 text-[#c5a059]' : ''}`} />
                </a>

                {/* Dropdown Menu Panel */}
                {servicesDropdownOpen && (
                  <div
                    id="services-dropdown-menu"
                    className="absolute top-full left-0 w-84 bg-[#111111] border border-white/10 rounded-2xl shadow-2xl p-3 z-50 animate-in fade-in slide-in-from-top-2 duration-150 backdrop-blur-xl"
                  >
                    <div className="px-3 py-2 border-b border-white/10 mb-2">
                      <p className="text-xs font-semibold text-[#c5a059] uppercase tracking-wider">全方位數位服務</p>
                      <p className="text-xs text-neutral-400 mt-0.5">點擊查看規格或直接預約諮詢</p>
                    </div>
                    <div className="space-y-1">
                      {SERVICES_LIST.map((srv) => (
                        <a
                          key={srv.id}
                          href={`#services`}
                          onClick={() => {
                            if (onSelectServiceModal) onSelectServiceModal(srv.id);
                            setServicesDropdownOpen(false);
                          }}
                          className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-white/5 transition-colors group/item border border-transparent hover:border-white/5"
                        >
                          <div className="p-2 rounded-lg bg-[#1a1a1a] border border-white/10 group-hover/item:border-[#c5a059]/50 shrink-0">
                            {serviceIconMap[srv.id] || <Layout className="w-4 h-4 text-[#c5a059]" />}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium text-neutral-200 group-hover/item:text-[#c5a059] transition-colors">
                                {srv.title.split(' (')[0]}
                              </span>
                              {srv.badge && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#c5a059]/20 text-[#c5a059] border border-[#c5a059]/30 font-semibold">
                                  {srv.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-neutral-400 line-clamp-1 mt-0.5">{srv.shortDesc}</p>
                          </div>
                        </a>
                      ))}
                    </div>
                    <div className="pt-2 mt-2 border-t border-white/10">
                      <a
                        href="#services"
                        className="flex items-center justify-between px-3 py-2 text-xs font-medium text-[#c5a059] hover:text-[#e0c487] hover:bg-white/5 rounded-lg transition-colors"
                        onClick={() => setServicesDropdownOpen(false)}
                      >
                        <span>瀏覽全部 6 大核心服務</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                )}
              </div>

              <a
                href="#portfolio"
                id="nav-portfolio-link"
                className="px-3.5 py-2 text-sm font-medium text-neutral-300 hover:text-[#c5a059] hover:bg-white/5 rounded-xl transition-colors"
              >
                精選案例
              </a>

              <a
                href="#why-us"
                id="nav-why-link"
                className="px-3.5 py-2 text-sm font-medium text-neutral-300 hover:text-[#c5a059] hover:bg-white/5 rounded-xl transition-colors"
              >
                核心優勢
              </a>

              <a
                href="#contact"
                id="nav-contact-link"
                className="px-3.5 py-2 text-sm font-medium text-neutral-300 hover:text-[#c5a059] hover:bg-white/5 rounded-xl transition-colors"
              >
                聯絡我們
              </a>
            </nav>

            {/* Right Action CTA Button */}
            <div className="hidden md:flex items-center space-x-3">
              <a
                href="#contact"
                id="nav-cta-btn"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-black bg-gradient-to-r from-[#c5a059] to-[#d8b56f] hover:from-[#d8b56f] hover:to-[#ecd192] shadow-lg shadow-[#c5a059]/20 active:scale-95 transition-all"
              >
                <span>預約專案諮詢</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex md:hidden items-center gap-2">
              <a
                href={`tel:${COMPANY_INFO.phone}`}
                className="p-2 rounded-xl bg-[#161616] border border-white/10 text-[#c5a059] hover:bg-white/10 transition-colors"
                aria-label="一鍵撥號"
              >
                <Phone className="w-5 h-5" />
              </a>
              <button
                id="mobile-menu-toggle-btn"
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2.5 rounded-xl bg-[#161616] border border-white/10 text-neutral-200 hover:text-white hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
                aria-expanded={mobileMenuOpen}
                aria-label="開啟行動選單"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer / Panel */}
        {mobileMenuOpen && (
          <div
            id="mobile-drawer-menu"
            className="md:hidden bg-[#111111] border-b border-white/10 px-4 pt-3 pb-6 space-y-4 animate-in slide-in-from-top-4 duration-200 max-h-[85vh] overflow-y-auto"
          >
            {/* Quick Address banner */}
            <div className="p-3 rounded-xl bg-[#1a1a1a] border border-white/10 text-xs text-neutral-300 flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-white">實體據點：</span>
                {COMPANY_INFO.address}
              </div>
            </div>

            <div className="space-y-1">
              <a
                href="#home"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-xl text-base font-medium text-neutral-100 hover:bg-white/5 transition-colors"
              >
                首頁
              </a>

              {/* Mobile Services Accordion */}
              <div className="rounded-xl bg-[#161616] p-2 space-y-1 border border-white/5">
                <div className="px-3 py-1.5 text-xs font-bold text-[#c5a059] uppercase tracking-wider">
                  服務項目
                </div>
                {SERVICES_LIST.map((srv) => (
                  <a
                    key={srv.id}
                    href="#services"
                    onClick={() => {
                      if (onSelectServiceModal) onSelectServiceModal(srv.id);
                      setMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-2.5 px-3 py-2 text-sm text-neutral-200 hover:text-[#c5a059] hover:bg-white/5 rounded-lg transition-colors"
                  >
                    <div className="p-1 rounded bg-[#222222] text-[#c5a059]">
                      {serviceIconMap[srv.id] || <Layout className="w-3.5 h-3.5" />}
                    </div>
                    <span>{srv.title.split(' (')[0]}</span>
                  </a>
                ))}
              </div>

              <a
                href="#portfolio"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-xl text-base font-medium text-neutral-100 hover:bg-white/5 transition-colors"
              >
                精選案例
              </a>

              <a
                href="#why-us"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-xl text-base font-medium text-neutral-100 hover:bg-white/5 transition-colors"
              >
                核心優勢
              </a>

              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-4 py-3 rounded-xl text-base font-medium text-neutral-100 hover:bg-white/5 transition-colors"
              >
                聯絡我們（大安分部地圖）
              </a>
            </div>

            <div className="pt-2 border-t border-white/10 space-y-3">
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold text-black bg-[#c5a059] hover:bg-[#d8b56f] shadow-lg shadow-[#c5a059]/25 transition-colors"
              >
                <span>立即預約專案諮詢</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <div className="flex items-center justify-center gap-4 text-xs text-neutral-400">
                <a href={`tel:${COMPANY_INFO.phone}`} className="flex items-center gap-1 hover:text-[#c5a059]">
                  <Phone className="w-3.5 h-3.5 text-[#c5a059]" />
                  {COMPANY_INFO.phone}
                </a>
                <span>•</span>
                <a href={`mailto:${COMPANY_INFO.email}`} className="flex items-center gap-1 hover:text-[#c5a059]">
                  <Mail className="w-3.5 h-3.5 text-[#c5a059]" />
                  {COMPANY_INFO.email}
                </a>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
