import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, Layers, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';
import { ServiceItem } from '../types';

interface ServiceModalProps {
  service: ServiceItem | null;
  onClose: () => void;
  onSelectForConsultation: (serviceTitle: string) => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({
  service,
  onClose,
  onSelectForConsultation,
}) => {
  if (!service) return null;

  return (
    <AnimatePresence>
      <div
        id="service-detail-modal"
        className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/80 backdrop-blur-md"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="relative w-full max-w-2xl bg-[#121212] border border-white/15 rounded-3xl shadow-2xl overflow-hidden my-8"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header Image */}
          <div className="relative h-56 sm:h-64 w-full overflow-hidden bg-[#161616]">
            <img
              src={service.image}
              alt={service.title}
              className="w-full h-full object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/50 to-transparent" />
            
            <button
              id="close-modal-btn"
              onClick={onClose}
              className="absolute top-4 right-4 p-2.5 rounded-full bg-[#111]/80 text-neutral-300 hover:text-white hover:bg-[#222] border border-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-[#c5a059] cursor-pointer"
              aria-label="關閉彈窗"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="absolute bottom-4 left-6 right-6 text-white">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-[#111111]/90 backdrop-blur-md text-neutral-200 border border-white/15 shadow-sm">
                  {service.category}
                </span>
                {service.badge && (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-[#c5a059] text-black flex items-center gap-1 shadow-sm">
                    <Sparkles className="w-3 h-3" />
                    {service.badge}
                  </span>
                )}
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white">{service.title}</h3>
            </div>
          </div>

          {/* Modal Content Body */}
          <div className="p-6 sm:p-8 space-y-6 max-h-[60vh] overflow-y-auto">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#c5a059] mb-2">服務概述</h4>
              <p className="text-neutral-300 leading-relaxed text-base">{service.fullDesc}</p>
            </div>

            {/* Key Features */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#c5a059] mb-3 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-[#c5a059]" />
                核心規格與技術特色
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {service.features.map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-sm text-neutral-200 bg-[#181818] p-3 rounded-xl border border-white/5">
                    <CheckCircle2 className="w-4 h-4 text-[#c5a059] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Deliverables */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#c5a059] mb-3 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
                交付項目與保證
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {service.deliverables.map((deliv, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-sm text-neutral-200 bg-[#181818] p-3 rounded-xl border border-white/5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#c5a059] mt-2 shrink-0" />
                    <span>{deliv}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tags */}
            <div className="pt-2">
              <div className="flex flex-wrap gap-2">
                {service.tags.map((tag, idx) => (
                  <span key={idx} className="px-3 py-1 bg-[#1a1a1a] text-neutral-300 rounded-lg text-xs font-medium border border-white/5">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="p-4 sm:p-6 bg-[#0e0e0e] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-xs text-neutral-400 text-center sm:text-left">
              有特別的客製需求？我們提供大安分部實體與線上免費諮詢。
            </p>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="w-1/2 sm:w-auto px-4 py-2.5 text-sm font-semibold text-neutral-300 hover:text-white hover:bg-white/5 rounded-xl transition-colors cursor-pointer"
              >
                關閉
              </button>
              <button
                type="button"
                id="modal-select-service-btn"
                onClick={() => {
                  onSelectForConsultation(service.title);
                  onClose();
                }}
                className="w-1/2 sm:w-auto px-5 py-2.5 text-sm font-bold text-black bg-gradient-to-r from-[#c5a059] to-[#d8b56f] hover:from-[#d8b56f] hover:to-[#ecd192] rounded-xl transition-all shadow-md shadow-[#c5a059]/25 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
              >
                立即洽詢此項目
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
