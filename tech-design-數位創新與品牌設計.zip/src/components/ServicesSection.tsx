import React, { useState } from 'react';
import {
  Layout,
  Palette,
  Code,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  ArrowRight,
  CheckCircle2,
  Filter,
} from 'lucide-react';
import { SERVICES_LIST } from '../data/mockData';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onOpenServiceModal: (service: ServiceItem) => void;
  onSelectForConsultation: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onOpenServiceModal,
  onSelectForConsultation,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: '全部服務項目' },
    { id: '前端與視覺', label: '前端與視覺' },
    { id: '體驗策略', label: '體驗策略' },
    { id: '工程研發', label: '工程研發' },
    { id: '品牌策略', label: '品牌策略' },
    { id: '行銷增長', label: '行銷增長' },
    { id: '運維保障', label: '運維保障' },
  ];

  const filteredServices = selectedCategory === 'all'
    ? SERVICES_LIST
    : SERVICES_LIST.filter((s) => s.category === selectedCategory);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-5 h-5 text-[#c5a059]" />;
      case 'Palette':
        return <Palette className="w-5 h-5 text-[#c5a059]" />;
      case 'Code':
        return <Code className="w-5 h-5 text-[#c5a059]" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#c5a059]" />;
      case 'TrendingUp':
        return <TrendingUp className="w-5 h-5 text-[#c5a059]" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-5 h-5 text-[#c5a059]" />;
      default:
        return <Layout className="w-5 h-5 text-[#c5a059]" />;
    }
  };

  return (
    <section id="services" className="py-20 sm:py-24 bg-[#0a0a0a] relative scroll-mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Title Section */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#c5a059]/15 text-[#c5a059] border border-[#c5a059]/30 text-xs font-bold tracking-wider uppercase mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#c5a059]" />
            <span>OUR CORE SERVICES</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            全方位數位創新增長解決方案
          </h2>
          <p className="mt-4 text-base sm:text-lg text-neutral-400 leading-relaxed">
            我們結合頂尖設計美學與工程實力，從網頁設計、UI/UX 到客製化系統，為您的事業注入強大成長動能。
          </p>

          {/* Category Filter Pills (Bento Style) */}
          <div className="mt-8 flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-2 no-scrollbar">
            <div className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-400 font-medium shrink-0">
              <Filter className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>篩選：</span>
            </div>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap shrink-0 ${
                  selectedCategory === cat.id
                    ? 'bg-[#c5a059] text-black shadow-md shadow-[#c5a059]/20 font-bold'
                    : 'bg-[#141414] text-neutral-300 hover:bg-[#202020] border border-white/10 hover:border-white/20'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3-Column Responsive Bento Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredServices.map((service) => (
            <div
              key={service.id}
              id={`service-card-${service.id}`}
              className="group bg-[#121212] rounded-2xl border border-white/10 hover:border-[#c5a059]/50 overflow-hidden shadow-xl hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between"
            >
              {/* Card Top: Visual Image with Category Badge */}
              <div className="relative h-52 sm:h-56 w-full overflow-hidden bg-[#1a1a1a]">
                <img
                  src={service.image}
                  alt={service.title}
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-transparent to-transparent opacity-80 group-hover:opacity-60 transition-opacity" />

                {/* Badges on Image */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-[#111111]/90 backdrop-blur-md text-neutral-200 border border-white/15 shadow-sm">
                    {service.category}
                  </span>
                  {service.badge && (
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#c5a059] text-black shadow-sm">
                      {service.badge}
                    </span>
                  )}
                </div>

                {/* Floating Icon in Corner */}
                <div className="absolute bottom-3 right-3 p-2.5 rounded-xl bg-[#1a1a1a]/95 backdrop-blur-md shadow-md text-[#c5a059] border border-white/10 group-hover:bg-[#c5a059] group-hover:text-black transition-colors">
                  {getServiceIcon(service.iconName)}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-[#c5a059] transition-colors">
                    {service.title}
                  </h3>
                  <p className="mt-2.5 text-sm text-neutral-400 leading-relaxed">
                    {service.shortDesc}
                  </p>

                  {/* Highlights checklist */}
                  <div className="mt-4 pt-4 border-t border-white/10 space-y-2">
                    {service.features.slice(0, 3).map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-neutral-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#c5a059] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>

                  {/* Tags */}
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {service.tags.slice(0, 3).map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-0.5 bg-[#1a1a1a] text-neutral-400 text-[11px] font-medium rounded-lg border border-white/5"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => onOpenServiceModal(service)}
                    className="text-xs font-semibold text-neutral-400 hover:text-white py-2 px-3 rounded-xl hover:bg-white/5 transition-colors"
                  >
                    查看完整規格
                  </button>

                  <a
                    href="#contact"
                    onClick={() => onSelectForConsultation(service.title)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-black bg-[#c5a059] hover:bg-[#d8b56f] py-2 px-3.5 rounded-xl transition-all shadow-md shadow-[#c5a059]/20"
                  >
                    <span>立即諮詢</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner for Custom Consultation */}
        <div className="mt-16 rounded-3xl bg-gradient-to-r from-[#141414] via-[#1a1a1a] to-[#141414] border border-[#c5a059]/30 text-white p-8 sm:p-10 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl sm:text-2xl font-bold text-white">需要專屬的客製化專案規劃？</h3>
            <p className="text-neutral-400 text-sm max-w-xl">
              我們在中國文化大學大安分部 3~6 樓設有專案討論中心，歡迎提前預約線下面對面探討。
            </p>
          </div>
          <a
            href="#contact"
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#c5a059] to-[#d8b56f] hover:from-[#d8b56f] hover:to-[#ecd192] text-black font-bold text-sm transition-all shadow-lg shadow-[#c5a059]/25 active:scale-95"
          >
            <span>預約大安分部實體諮詢</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
};
