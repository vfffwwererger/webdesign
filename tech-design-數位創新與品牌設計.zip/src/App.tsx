/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroCarousel } from './components/HeroCarousel';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { ServiceModal } from './components/ServiceModal';
import { ServiceItem } from './types';
import { SERVICES_LIST } from './data/mockData';

export default function App() {
  const [activeModalService, setActiveModalService] = useState<ServiceItem | null>(null);
  const [selectedServiceForConsultation, setSelectedServiceForConsultation] = useState<string>('');

  const handleSelectServiceById = (serviceId: string) => {
    const srv = SERVICES_LIST.find((s) => s.id === serviceId);
    if (srv) {
      setActiveModalService(srv);
    }
  };

  const handleSelectForConsultation = (serviceTitle: string) => {
    setSelectedServiceForConsultation(serviceTitle);
    // Smooth scroll to contact form
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a] text-[#e5e5e5] selection:bg-[#c5a059] selection:text-black pb-14 md:pb-0 font-sans">
      {/* Navigation Header */}
      <Navbar onSelectServiceModal={handleSelectServiceById} />

      {/* Main Content Area */}
      <main className="flex-1 w-full">
        {/* 1. Hero Carousel Banner */}
        <HeroCarousel />

        {/* 2. Core Services (Card-based layout) */}
        <ServicesSection
          onOpenServiceModal={(service) => setActiveModalService(service)}
          onSelectForConsultation={handleSelectForConsultation}
        />

        {/* 3. Selected Portfolio Cases */}
        <PortfolioSection />

        {/* 4. Core Advantages & Testimonials */}
        <WhyChooseUs />

        {/* 5. Contact Section with Cultural University Daan Branch Address & Map */}
        <ContactSection selectedServicePreFill={selectedServiceForConsultation} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Floating Quick Actions & Desktop Back-to-top */}
      <FloatingActions />

      {/* Service Detail Modal */}
      <ServiceModal
        service={activeModalService}
        onClose={() => setActiveModalService(null)}
        onSelectForConsultation={handleSelectForConsultation}
      />
    </div>
  );
}
